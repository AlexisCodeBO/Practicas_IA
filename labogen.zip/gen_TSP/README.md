# GeneticTSP
Travelling salesman problem using genetic algorithms demo

# Running the app
This little app uses Tkinter for the GUI, so it should run in any platform.
You don't need any special dependency, only standard python3 modules.

For running the app you can enter the following command:

```bash
python3 tsp.py
```

