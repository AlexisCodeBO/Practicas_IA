[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
# Pacman project
<p align="center">
<p align="center">
<img src="https://upload.wikimedia.org/wikipedia/el/0/00/Pac-Man.png"> <br />
</p><br />

I have completed two Pacman projects of the UC Berkeley CS188 Intro to AI course, and you can find my solutions accompanied by comments.  

## Links
1. http://ai.berkeley.edu/search.html
2. http://ai.berkeley.edu/multiagent.html

## Author
* Petropoulakis Panagiotis petropoulakispanagiotis@gmail.com
